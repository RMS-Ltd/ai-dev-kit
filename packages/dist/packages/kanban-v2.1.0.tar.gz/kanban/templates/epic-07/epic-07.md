---
lifecycle: evergreen
ttl_days: null
created_at: 2025-12-04T12:01:57Z
expires_at: null
housekeeping_policy: keep
---

# Epic 7: UXR (User Experience Research)

**Status:** [TODO/IN PROGRESS/COMPLETE]
**Priority:** [HIGH/MEDIUM/LOW]
**Estimated Effort:** [X-Y hours]
**Created:** [YYYY-MM-DD]
**Last updated:** [YYYY-MM-DD] (vX.Y.Z.T+B – [summary])
**Branch:** `epic/X-slug`
**Version Schema:** `0.X.S.T+B`
**Production URL:** [Optional]

---

## Story Checklist

- [ ] **E07:S01 – [Story Title]** - [Status]
- [ ] **E07:S02 – [Story Title]** - [Status]
- [ ] **E07:S03 – [Story Title]** - [Status]

> **CRITICAL:** This Story Checklist is the **SINGLE SOURCE OF TRUTH** for story status and version markers.  
> **Forensic Marker Format:** `✅ COMPLETE (vRC.E.S.T+B)` (e.g., `✅ COMPLETE (v0.4.1.3+1)`)  
> **Release Workflow Requirement:** When Release Workflow (RW) Step 4 updates this Epic document, it MUST update **ALL sections**:
> - Epic header `Last updated` field
> - Story Checklist (status and version markers)
> - Detailed story sections (Status, Last updated, task checkboxes)
> - Any other references to the story/task being released
> 
> **Consistency Check:** After each RW, verify that Epic header, Story Checklist, and detailed sections all match.

---

## Overview

This epic encompasses uxr (user experience research) for the {PROJECT_NAME} project. It provides the foundational structure and capabilities needed to support the project's core objectives and enables other epics to build upon this foundation.

---

## Goals

1. Establish uxr (user experience research) infrastructure and foundational components
2. Define and implement core uxr (user experience research) patterns and standards
3. Create reusable uxr (user experience research) components and utilities
4. Document uxr (user experience research) architecture and best practices
5. Enable integration with other project epics and systems

---

## Stories

> **CRITICAL: Tier Delegation Principle**
> 
> **Epic documents MUST delegate Story detail to Story documents.** This Epic template should NOT duplicate Story-level information (Status, Priority, Goals, Tasks, Acceptance Criteria, etc.). Instead, Epic documents should:
> - Reference stories via Story Checklist (above)
> - Provide brief story summaries or links to Story documents
> - Delegate all detailed Story information to Story documents
> 
> **What belongs in Epic:**
> - ✅ Story Checklist (references only, with status/version markers)
> - ✅ Brief story summaries (1-2 sentences per story)
> - ✅ Links to Story documents
> - ✅ Epic-level dependencies and coordination
> 
> **What does NOT belong in Epic:**
> - ❌ Detailed story descriptions
> - ❌ Story-level goals, tasks, acceptance criteria
> - ❌ Task-level details
> - ❌ Story implementation details

### Story 1: User Research and Discovery

**Brief Summary:** user research and discovery for the {PROJECT_NAME} project, establishing the necessary components and processes to support the epic's objectives.

**Story Document:** [`story-01-user-research-and-discovery.md`](story-01-user-research-and-discovery.md)

### Story 2: Usability Testing and Validation

**Brief Summary:** usability testing and validation for the {PROJECT_NAME} project, establishing the necessary components and processes to support the epic's objectives.

**Story Document:** [`story-02-usability-testing-and-validation.md`](story-02-usability-testing-and-validation.md)

### Story 3: User Feedback Collection and Analysis

**Brief Summary:** user feedback collection and analysis for the {PROJECT_NAME} project, establishing the necessary components and processes to support the epic's objectives.

**Story Document:** [`story-03-user-feedback-collection-and-analysis.md`](story-03-user-feedback-collection-and-analysis.md)

### Story 4: User Journey Mapping and Experience Design

**Brief Summary:** user journey mapping and experience design for the {PROJECT_NAME} project, establishing the necessary components and processes to support the epic's objectives.

**Story Document:** [`story-04-user-journey-mapping-and-experience-design.md`](story-04-user-journey-mapping-and-experience-design.md)

### Story 5: UX Insights and Recommendations

**Brief Summary:** ux insights and recommendations for the {PROJECT_NAME} project, establishing the necessary components and processes to support the epic's objectives.

**Story Document:** [`story-05-ux-insights-and-recommendations.md`](story-05-ux-insights-and-recommendations.md)

---


## Dependencies

**Blocks:**
- [What this epic blocks]

**Blocked By:**
- [What blocks this epic]

**Coordinates With:**
- [Epic/Story coordination points]

---

## Risks & Mitigations

- Risk description — mitigation
- Risk description — mitigation

---

## References

- [Related docs, specs, diagrams]

---

## Maintenance Cadence

_For maintenance epics only._

- **Weekly:** [schedule items]
- **Monthly:** [schedule items]
- **Quarterly:** [schedule items]
- **As Needed:** [schedule items]
